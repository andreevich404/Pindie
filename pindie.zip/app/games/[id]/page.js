'use client';

import Styles from './Game.module.css';
import { getGameById } from '../../data/data-utils';

export default function GamePage(props) {
	const slug = props.params;
	const game = getGameById(slug.id);

	return (
		<main className="main">
			{
				game ? (
					<>
						<section className={Styles.game}>
							<iframe className={Styles.gameIframe} src={game.link}></iframe>
						</section>
						<section className={Styles.about}>
							<h2 className={Styles.aboutTitle}>{game.title}</h2>
							<div className={Styles.aboutContent}>
								<p className={Styles.aboutDescription}>{game.description}</p>
								<div className={Styles.aboutAuthor}>
									<p>Автор: <span className={Styles.aboutAccent}>{game.developer}</span></p>
								</div>
							</div>
							<div className={Styles.aboutVote}>
								<p className={Styles.aboutVoteAmount}>За игру уже проголосовали: <span className={Styles.aboutAccent}>{game.users.length}</span></p>
								<button onClick={() => {}} className={`button ${Styles.aboutVoteButton}`}>Голосовать</button>
							</div>
						</section>
					</>
				) : (
					<section className={Styles.game}>
						<p>Такой игры не существует 😢</p>
					</section>
				)
			}

		</main>
	);
}