import { Card } from '../Card/Card';
import Link from 'next/link';
import Styles from './CardsList.module.css';

export const CardsList = ({ id, title, data }) => {
	return (
		<section className={Styles.listSection}>
			<h2 className={Styles.listSectionTitle} id={id}>{title}</h2>
			<ul className={Styles.cardsList}>
				{data.map((item) => {
					return (
						<li className={Styles.cardsListItem} key={item.id}>
							<Link href={`/games/${item.id}`} className={Styles.cardListLink}>
								<Card {...item} />
							</Link>
						</li>
					);
				})}
			</ul>
		</section>
	);
};