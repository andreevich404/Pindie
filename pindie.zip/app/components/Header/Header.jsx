'use client';

import { useState } from 'react';
import Styles from './Header.module.css';
import Image from 'next/image';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Overlay } from '../Overlay/Overlay';
import { Popup } from '../Popup/Popup';
import { AuthForm } from '../AuthForm/AuthForm';

export const Header = () => {
	const pathname = usePathname();
	const [popupIsOpened, setPopupIsOpened] = useState(false);

	const openPopup = () => {
		setPopupIsOpened(true);
	};

	const closePopup = () => {
		setPopupIsOpened(false);
	};

	return (
		<header className={Styles.header}>
			<Link href="./index.html" className={Styles.logo}>
				<Image
					className={Styles.logoImage}
					src="./images/logo.svg"
					alt="Логотип Pindie"
					layout="responsive"
					width={100}
					height={100}
				/>
			</Link>
			<nav className={Styles.menu}>
				<ul className={Styles.menuList}>
					<li className={Styles.menuItem}>
						<Link href="/new" className={`${Styles.menuLink} ${pathname === '/new' ? Styles.menuLinkActive : ''}`}>Новинки</Link>
					</li>
					<li className={Styles.menuItem}>
						<Link href="/popular" className={`${Styles.menuLink} ${pathname === '/popular' ? Styles.menuLinkActive : ''}`}>Популярные</Link>
					</li>
					<li className={Styles.menuItem}>
						<Link href="/shooter" className={`${Styles.menuLink} ${pathname === '/shooter' ? Styles.menuLinkActive : ''}`}>Шутеры</Link>
					</li>
					<li className={Styles.menuItem}>
						<Link href="/runner" className={`${Styles.menuLink} ${pathname === '/runner' ? Styles.menuLinkActive : ''}`}>Ранеры</Link>
					</li>
					<li className={Styles.menuItem}>
						<Link href="/pixel" className={`${Styles.menuLink} ${pathname === '/pixel' ? Styles.menuLinkActive : ''}`}>Пиксельные</Link>
					</li>
					<li className={Styles.menuItem}>
						<Link href="/TDS" className={`${Styles.menuLink} ${pathname === '/TDS' ? Styles.menuLinkActive : ''}`}>TDS</Link>
					</li>
				</ul>
				<div className={Styles.auth}>
					<button className={Styles.authButton} onClick={openPopup}>Войти</button>
				</div>
			</nav>
			{popupIsOpened && (
				<>
					<Overlay popupIsOpened={popupIsOpened} closePopup={closePopup} />
					<Popup popupIsOpened={popupIsOpened} closePopup={closePopup}>
						<AuthForm />
					</Popup>
				</>
			)}
		</header>
	);
};
